package com.example.boardpratice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardpraticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoardpraticeApplication.class, args);
	}

}
